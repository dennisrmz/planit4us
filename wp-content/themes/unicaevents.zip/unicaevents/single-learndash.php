<?php
/*
Template Name: Course item
*/
get_template_part('single');
?>