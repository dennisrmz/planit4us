<?php
/**
Template Name: Donations list
 */
global $UNICAEVENTS_GLOBALS;
$UNICAEVENTS_GLOBALS['blog_filters'] = 'donations';

get_template_part('blog');
?>