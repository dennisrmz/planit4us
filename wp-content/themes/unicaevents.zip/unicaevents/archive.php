<?php
/*
Template Name: Archives
*/

get_template_part('blog');
?>