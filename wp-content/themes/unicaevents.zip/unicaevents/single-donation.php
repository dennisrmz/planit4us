<?php
/*
Template Name: Donations item
*/
get_template_part('single');
?>