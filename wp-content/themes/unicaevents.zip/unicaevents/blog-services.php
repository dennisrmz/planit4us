<?php
/**
Template Name: Services list
 */
global $UNICAEVENTS_GLOBALS;
$UNICAEVENTS_GLOBALS['blog_filters'] = 'services';

get_template_part('blog');
?>