<?php
/*
Template Name: Team member
*/
global $UNICAEVENTS_GLOBALS;
$UNICAEVENTS_GLOBALS['single_style'] = 'single-team';
get_template_part('single');
?>