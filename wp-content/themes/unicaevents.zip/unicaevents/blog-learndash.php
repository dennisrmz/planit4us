<?php
/**
Template Name: Courses list
 */
global $UNICAEVENTS_GLOBALS;
$UNICAEVENTS_GLOBALS['blog_filters'] = 'learndash';

get_template_part('blog');
?>