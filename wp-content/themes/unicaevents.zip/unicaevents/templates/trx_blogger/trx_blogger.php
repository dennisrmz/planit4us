<?php
// Autoload layouts in this folder
unicaevents_autoload_folder( 'templates/trx_blogger' );
?>