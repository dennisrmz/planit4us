<?php
/**
Template Name: Team members list
 */
global $UNICAEVENTS_GLOBALS;
$UNICAEVENTS_GLOBALS['blog_filters'] = 'team';

get_template_part('blog');
?>