<?php
/**
Template Name: Clients list
 */
global $UNICAEVENTS_GLOBALS;
$UNICAEVENTS_GLOBALS['blog_filters'] = 'clients';

get_template_part('blog');
?>